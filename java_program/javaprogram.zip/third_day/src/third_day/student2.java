package third_day;
import java.util.Scanner;
class student2 {
	int StudentId;
	String StudentName;
	String Phone;
	}
	class marks extends student2{



	int mark=600;
	int marks2=700;
	int marks3=600;

	public static void main(String aa[])
	{
	marks m=new marks();
	System.out.println(m.mark);
	m.StudentId=40;
	m.StudentName="Manjula";
	m.Phone="83e98t3";

	}
	}
