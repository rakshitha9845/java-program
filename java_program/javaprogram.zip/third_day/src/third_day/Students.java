package third_day;

public class Students {
	String name;
	public Students(String s) {
	name=s;
	}
	public Students() {
	name="unknown";
	}
	public static void main(String[] args) {
	Students s=new Students("rakshitha");
	Students a=new Students();
	System.out.println(s.name);
	System.out.println(a.name);
	}

}


