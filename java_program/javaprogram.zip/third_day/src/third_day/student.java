package third_day;

public class student {
	String name,rollno;
	void setName(String name) {
		this.name=name;
	}
	void setRollno(String roll) {
		this.rollno=roll;
	}
	String getName() {
		return name;
	}
	String getRollno() {
		return rollno;
	}
	public static void main(String aa[])
	{
	student t1=new student();
	t1.setName("Rakshitha");
	t1.setRollno("22");
	System.out.print(t1.getName()+" "+t1.getRollno());
	}
	}