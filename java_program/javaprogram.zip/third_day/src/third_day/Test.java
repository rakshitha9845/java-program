package third_day;

public class Test {
	public static void main(String aa[])
    {
     Employee e=new Employee("12","35000");
     System.out.print(e.getDetails());
}

}

class Emp
{
    String id,salary;

        Emp(String x,String  sal)
        {
            id=x;
            salary=sal;
        }    

    String getDetails()
    {
        return id+" "+salary;
    }
}

