package third_day;

public class Car {
	String brandname;
	String price;

	Car(String brandname, String price)
	{
	this.brandname=brandname;
	this.price=price;
	}
	String displaydetails()
	{
	return price+" "+brandname;
	}

	public static void main(String[] args) {
		Car c= new Car("echo","80000");
		System.out.println(c.displaydetails());


	}

}
//brand name
//price
//display details