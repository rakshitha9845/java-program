package test;

public class demo2 {

	public static void main(String[] args) {
		 try {
			    String var=null;
			    System.out.print(var.charAt(3));
		 }
		 catch(Exception e)
		{
			 System.out.print(e);
			 }
		}
}

	