package test;

public class demoo3 {

	public static void main(String[] args) {
		 int number=10;
	        try{
	         if(number>=10 && number<=20)
	         {
	             throw new NumberRange("Number is not in range exception");
	         }
	        }
	                 catch(NumberRange n)
	                 {
	                    System.out.println(n); 
	                 }
	    }
	}
	 

	class NumberRange extends Exception
	{
	 
	    public NumberRange(String message) {
	        super(message);

	    }
	}