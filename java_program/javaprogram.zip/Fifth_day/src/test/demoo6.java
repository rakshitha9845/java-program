package test;

public class demoo6 {

	public static void main(String[] args) {
		String vowels[]= {"a,A","e,E","i,I","o,O","u,U"};

	    for(int i=0;i<vowels.length;i++)
	    {
	        System.out.println(vowels[i]);
	    }

	}

}
