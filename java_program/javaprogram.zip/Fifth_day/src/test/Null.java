package test;

public class Null {

	public static void main(String[] args) {
		String nullString = null;
		try {
			if (nullString.equals("any_string"))
				System.out.println("Both strings are same.");
			else
				System.out.println("Both strings are same.");
		} catch (NullPointerException e) {
			System.out.println("NullPointerException occurred");
		}
	}

}
