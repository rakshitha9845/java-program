package method;

public class change_variable {
	int i=9;
	void changevariable()
	{
	i=90;
	}

	public static void main(String[] args) {
		change_variable ob1=new change_variable();
		change_variable ob2=new change_variable();
		change_variable ob3=new change_variable();
		ob1.changevariable();
		System.out.println(ob1.i);
		System.out.println(ob2.i);
		System.out.println(ob3.i);
	}

}
