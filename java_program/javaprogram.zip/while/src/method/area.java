package method;
import java.util.Scanner;
public class area {
	private static final int PI = (int) 3.14;
	static int factorial(int n)
	{
		if(n==0)
			return 1;
		else
			return(n*factorial(n-1));
	}
	 public void area(int side)
	    {
	        System.out.print(side*side);
	    }
	    void area(float radius)
	    {
	        System.out.print(31.4f*radius*radius);
	    }
	    void area(int l,int b)
	    {
	        System.out.print(l*b);
	    }
	    public int add(int x,int y)
	    {
	        return x+y;
	    }

	public static void main(String[] args) {
		area a = new area();
		a.area(22.5f);
        a.area(2);
        a.area(3,9);
        int sum=a.add(3,8);
        System.out.print(sum);
	    }
	}