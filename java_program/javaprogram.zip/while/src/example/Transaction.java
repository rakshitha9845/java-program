package example;
import java.util.Scanner;
public class Transaction {
int accountnumber;
int balance =600000;
Scanner s=new Scanner(System.in);



public int getAccountnumber()
{
return accountnumber;
}
void execute()
{


System.out.println("the account balance "+this.balance);
balance=s.nextInt();
}
}
class balanceenquiry extends Transaction
{

void execute()
{

System.out.println("TOtal balance "+ this.balance);

}
}
class withdraw extends Transaction
{

int Afterbalance;
int amountTOwithdraw;

void amount()
{
System.out.println("the amount to be withdraw");
amountTOwithdraw=s.nextInt();
}
void execute1()
{

Afterbalance=this.balance-amountTOwithdraw;
System.out.println("the balance aftr withdraw in account "+Afterbalance);

}
}
class Deposite extends Transaction
{

int AfterDepbalance;
int amountTODeposite;

void amount()
{
System.out.println("the amount to be deposite");
amountTODeposite=s.nextInt();
}
void execute1()
{



AfterDepbalance=this.balance+AfterDepbalance;
System.out.println("the balance aftr withdraw in account "+AfterDepbalance);
}
}
class Bank
{
public static void main(String aa[])
{
balanceenquiry b=new balanceenquiry();
withdraw w=new withdraw();
Deposite d=new Deposite();

b.execute();
w.amount();
w.execute1();
d.amount();
d.execute1();

}
}
