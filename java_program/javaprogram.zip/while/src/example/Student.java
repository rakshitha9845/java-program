package example;

import java.util.Scanner;

public class Student {
	int studentid;
	String studentname,phone;
	Scanner s= new Scanner(System.in);
	void ReadDetails()
	{
		System.out.println("Enter id");
	    studentid=s.nextInt();
	    System.out.println("Enter name");
	    studentname=s.next();
	    System.out.println("Enter phone");
	    phone=s.next();
	}
	public void displayDetails()
	{
		  System.out.println("ID :"+studentid);
		    System.out.println("Name:"+studentname);
		    System.out.println("Phoneno :"+phone);
	}
	}
class marks extends Student{
	int m1,m2,m3;
Scanner s=new Scanner(System.in);
public void ReadMarks()
{
	System.out.println("marks of Maths");
    m1=s.nextInt();
    System.out.println("marks of English");
    m2=s.nextInt();
    System.out.println("marks of Hindi");
    m3=s.nextInt();
}
void display() {
	System.out.println("marks...m1:"+m1);
	System.out.println("marks...m2:"+m2);
	System.out.println("marks...m3:"+m3);
}
//void Result() {
//	int r;
//	r=m1+m2+m3;
//	System.out.println("The total marks is:"+r);
//}
//void Pecentage() {
//	float p;
//	p=(m1+m2+m3)+100/300;
//	System.out.println("The percentage is:"+p);
//}
void calculateResult() {
		int r;
		r=m1+m2+m3;
		System.out.println("The total marks is:"+r);
	}
	void Pecentage() {
		float p;
		p=(m1+m2+m3)/3;
		System.out.println("The percentage is:"+p);
	}	
	void displayResult()
	{
		int pecentage;
		pecentage= (m1+m2+m3)/3;
		if(pecentage>=90)
		{
			System.out.println("first class");
		}
		else if(pecentage>=80)
		{
			System.out.println("second class");
		}
		else if(pecentage>=70)
		{
			System.out.println("third class");
		}
		else
		{
			System.out.println("fail");
		}
	}
}
