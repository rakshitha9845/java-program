package example;

public class test {

	public static void main(String[] args) {
		marks m=new marks();
        m.ReadDetails();
        m.displayDetails();
        m.ReadMarks();
        m.display();
        m.calculateResult();
        m.Pecentage();
        m.displayResult();
	}
}
