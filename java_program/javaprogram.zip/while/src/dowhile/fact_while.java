package dowhile;

public class fact_while {

	public static void main(String[] args) {
		int fact=1;
		int i=1,num=6;
		while(i<=num) {
		fact=fact*i;
		i++;
		}
		System.out.print("Factorial of number "+num + " is " +fact);
		

	}

}
