package dowhile;

public class factorial {

	public static void main(String[] args) {
		int num=2;
		int i=1;
		do {
			System.out.print(num*i);
			i++;

		}
		while(i<=10);
	}

}

