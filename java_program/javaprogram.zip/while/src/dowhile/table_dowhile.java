package dowhile;

public class table_dowhile {

	public static void main(String[] args) {
		int i=1,a=5,num;
		do
		{
		num=a*i;
		i++;
		System.out.println(num);
		}
		while(i<=10);

	}

}
