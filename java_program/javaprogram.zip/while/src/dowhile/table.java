package dowhile;

public class table {

	public static void main(String[] args) {
		int num=7;
	      int i = 1;
	      while (i <= 10) {
	            System.out.println(i * num);
	            i++;
	        }

	}

}
