package dowhile;

public class fibo_dowhile {

	public static void main(String[] args) {
		int num=0,num1=1,num2,i=0;
		System.out.print(num+" "+num1+" ");

		do{
		num2=num1+num;
		System.out.print(" "+num2);
		num=num1;
		num1=num2;
		i++;

		}while(i<=20);
	}

}
