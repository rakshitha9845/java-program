package testing;

public class avg {

	public static void main(String[] args) {
		int a=5, b=4, c=2,d=3,e=5;
		System.out.println("average of 5 numbers: "+(a+b+c+d+e)/5);

	}

}
