package testing;

public class even_odd {

	public static void main(String[] args) {
		int n=5;
		if(n%2==0)
		System.out.println("number is even ");
		else
		System.out.println("number is odd ");

	}

}
