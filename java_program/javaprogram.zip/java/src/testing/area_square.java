package testing;

public class area_square {

	public static void main(String[] args) {
		int a=6;
		int area_square=a*a;
		System.out.println("Area of Square is: "+area_square);

	}

}
