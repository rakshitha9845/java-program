package testing;

public class area_rect {

	public static void main(String[] args) {
		int length=5;
		int breadth=6;
		int area=length*breadth;
		System.out.println("Area of rectangle is: "+area);

	}

}
