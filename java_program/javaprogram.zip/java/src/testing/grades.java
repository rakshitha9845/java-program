package testing;

public class grades {

	public static void main(String[] args) {
		int m=65;
		if(m>=80)
			System.out.print("The student grade is A");
		else if(m>=50 && m<80)
			System.out.print("The student grade is B");
		else
			System.out.print("The student grade is C");

	}

}
