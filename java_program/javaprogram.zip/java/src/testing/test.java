package testing;

public class test {

	public static void main(String[] args) {
		System.out.println("My Details:");
		System.out.println("My Name is: Rakshitha");
		System.out.println("I am learning arisglobal technology");
		System.out.println("My Age is 22");

	}

}
