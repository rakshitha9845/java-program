package testing;

public class electricity_bill {

	public static void main(String[] args) {
		 int bill=125;
		    if(bill<=50)
		    {
		        System.out.println("free");
		    }
		    else if(bill>50 && bill<=100)
		    {
		        bill=bill-50;
		        System.out.println(bill*6);
		    }
		    else if(bill>100 && bill<=150)
		    {
		        bill=(bill-100)*8+(50*6);
		        System.out.println(bill);
		    }
		    else {
		        bill=(bill-150)*9+(50*8)+(50*6);
		        System.out.print(bill);
		    }

	}

}
