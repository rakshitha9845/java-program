package testing;

public class circle {

	public static void main(String[] args) {
		final double pi = 3.14;
		int r = 3;
		double area= pi*r*r;
		System.out.println("Area of circle "+area);

	}

}
