package testing;

public class bill {

	public static void main(String[] args) {
		int calls=900;
		if(calls<=100) {
			System.out.println("call is free");
		}
		else if(calls<100 && calls<=200) {
			calls=calls-100;
			System.out.println(calls);
		}
		else if(calls>200 && calls<=300)
	    {
	        calls=(calls-200)*2+100;
	        System.out.println(calls);
	    }
	    else {
	        calls=(calls-300)*3+300;
	        System.out.print(calls);
	    }

		
	}

}
