package testing;

public class simple_interest {

	public static void main(String[] args) {
		float p=250, r=5, t=4,si;
		si= (p*r*t)/100;
		System.out.println("Simple interest is "+si);

	}

}
