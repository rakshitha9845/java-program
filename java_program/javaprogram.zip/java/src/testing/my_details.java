package testing;

public class my_details {

	public static void main(String[] args) {
		String name="Rakshitha", technology="java";
		int age=22;
		System.out.println("Details...");
		System.out.println("My Name is "+name+"\n I am learning "+technology+"\n my age is " +age);

	}

}
