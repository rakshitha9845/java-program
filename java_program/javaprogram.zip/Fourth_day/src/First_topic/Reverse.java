package First_topic;

public class Reverse {
	
		public static void main(String[] args)
		{
			String input = "Hello";
			StringBuilder input1 = new StringBuilder();
			input1.append(input);
			input1.reverse();
			System.out.println(input1);
		}
}

