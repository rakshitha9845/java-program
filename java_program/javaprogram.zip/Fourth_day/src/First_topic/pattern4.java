package First_topic;

public class pattern4 {

	public static void main(String[] args) {
		int rows = 5;
		for (int m= 0; m<= rows; m++)
		{
			for (int n=1; n<=rows-m; n++)
			{
				System.out.print(" ");
			}
			for (int p=0;p<=m;p++)
			{
				System.out.print("*");
			}
		System.out.println("");
		}
	}
}
