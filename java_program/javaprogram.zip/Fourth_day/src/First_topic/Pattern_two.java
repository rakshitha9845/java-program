package First_topic;

public class Pattern_two {

	public static void main(String[] args) {
		int m, n,number, num=5;   
		for(m=0; m<num; m++)  
		{   
			number=1;   
			for(n=0; n<=m; n++)  
			{   
				System.out.print(number+ " ");   
				number++;   
			}     
		System.out.println();   
		}   
	}   
} 