package First_topic;

public class Ascii {

	public static void main(String[] args) {
		for(int i = 65; i <= 90; i++)
		{
			System.out.println(" The ascii value of " + (char)i + " = " + i);
		}
	}

}
