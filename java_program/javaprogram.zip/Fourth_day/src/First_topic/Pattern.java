package First_topic;

public class Pattern {
	public static void main(String[] args) {
		int rows = 4;
		for (int m=rows; m>=1; m--)
		{
			for (int n=1; n<=(m * 2) -1; n++)
			{
				System.out.print("*");
			}
			System.out.println();
			for (int p=rows; p>=m; p--)
			{
				System.out.print(" ");
			}
		}
	}
}
