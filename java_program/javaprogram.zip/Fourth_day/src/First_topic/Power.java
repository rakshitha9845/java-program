package First_topic;

public class Power {

	public static void main(String[] args) {
		int baseno = 2, exponent = 5;
		long temp = 1;
		while (exponent != 0) {
			temp *= baseno;
			exponent--;
		}
		System.out.println("Result: " + temp);

	}

}
