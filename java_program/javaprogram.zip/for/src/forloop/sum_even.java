package forloop;

public class sum_even {

	public static void main(String[] args) {
		int sum=0;
		for(int i=10;i<=100;i=i+2)
		sum=sum+i;
		System.out.println("sum of even number 100 is "+sum);
	}

}
