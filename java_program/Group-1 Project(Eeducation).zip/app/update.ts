export class Update {
    id!:string;
    name!:string;
    email!: string;
    course!:string;
}

