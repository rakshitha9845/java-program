import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AddComponent } from './add/add.component';
import { CourseComponent } from './course/course.component';
import { DeleteComponent } from './delete/delete.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { StudentComponent } from './student/student.component';
import { UpdateComponent } from './update/update.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'course',component:CourseComponent},
  {path:'about',component:AboutComponent},
  {path:'student',component:StudentComponent},
  {path:'login',component:LoginComponent},
  {path:'delete',component:DeleteComponent},
  {path:'update',component:UpdateComponent},
  {path:'add',component:AddComponent},
  {path:'logout',component:LogoutComponent},






];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
