package demoOfMaven.mavendemo3;

import org.springframework.stereotype.Component;



@Component
public class MyMessage {



public MyMessage()
{
System.out.println("inside constructor...");
}
void display()
{
System.out.println("inside method...");
}
}