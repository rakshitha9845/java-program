package demoOfMaven.mavendemoo3;

import org.springframework.stereotype.Component;
@Component
public class Address {

	public Address()
	{
	System.out.println("Student adress is");
	}
	void display()
	{
	System.out.println("Padukone");
	}
	}