package demoOfMaven.mavendemoo3;

import org.springframework.beans.factory.annotation.Autowired;


public class Student {
@Autowired

Address add;


public Address getAdd() {
	return add;
}

@Autowired
public void setAdd(Address add) {
	this.add = add;
}


void displayAddress()
{
add.display();
}
}