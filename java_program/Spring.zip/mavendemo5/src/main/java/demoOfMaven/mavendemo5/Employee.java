package demoOfMaven.mavendemo5;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {

@Autowired

Salary sal;


public Salary getSal() {
	return sal;
}

@Autowired

public void setSal(Salary sal) {
	this.sal = sal;
}


void displaySalary()
{
sal.display();
}
}