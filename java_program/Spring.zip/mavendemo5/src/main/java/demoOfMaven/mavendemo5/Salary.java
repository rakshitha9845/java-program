package demoOfMaven.mavendemo5;

import java.util.Scanner;

public class Salary {
public Salary()
{
System.out.println("Employee salary details :");
}
void display()
{
//System.out.println("4LPA");
//}
//}

int oldSalaryPerMonth;
	int hike;

	Scanner in = new Scanner(System.in);
	
	System.out.println("Enter your old salary per month:");
	oldSalaryPerMonth = in.nextInt();
	
	System.out.println("Enter your hike percentage:");
	hike = in.nextInt();
	
	int presentSalaryPerMonth = oldSalaryPerMonth + (oldSalaryPerMonth * hike/100);
	
	
	System.out.println("After hike your present salary per month is: " + presentSalaryPerMonth );
}
}