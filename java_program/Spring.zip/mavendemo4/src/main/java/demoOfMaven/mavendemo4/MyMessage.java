package demoOfMaven.mavendemo4;

import org.springframework.stereotype.Component;



@Component
public class MyMessage {



public MyMessage()
{
System.out.println("inside constructor...");
}
void display()
{
System.out.println("inside method...");
}
}