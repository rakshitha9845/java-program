package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;
import java.util.List;
import java.util.Optional;
@Service
public class StudentService {
@Autowired
StudentRepository repository;
public List<Student> getAllStudent()
{
return repository.findAll();
}
public void saveStudent(Student s)
{
repository.save(s);
}
public void deleteStudent(String id)
{
repository.deleteById(id);
}
public Optional<Student> getStudent(String id)
{
return repository.findById(id);
}
public void updateStudent(Student s,String id) {
repository.getById(id);
repository.save(s);
}
}

