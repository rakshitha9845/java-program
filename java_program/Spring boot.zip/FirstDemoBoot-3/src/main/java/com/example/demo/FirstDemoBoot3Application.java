package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Student;

import com.example.demo.repository.StudentRepository;

@SpringBootApplication
public class FirstDemoBoot3Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(FirstDemoBoot3Application.class, args);
	}
@Autowired
StudentRepository repository;
@Override
public void run(String... args)throws Exception{
	this.repository.save(new Student("ss","23","eee","666"));
	this.repository.save(new Student("rr","27","eszx","567"));
	this.repository.save(new Student("v ","29","exb ","7y7y"));
}
}
