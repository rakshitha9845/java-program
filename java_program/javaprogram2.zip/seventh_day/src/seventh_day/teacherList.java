package seventh_day;

import java.util.HashMap;
import java.util.Map;

public class teacherList {

	public static void main(String[] args) {
		HashMap<String,Teacher> map=new HashMap<>();
		Teacher t1=new Teacher(1,"10th");
		Teacher t2=new Teacher(2,"9th");
		Teacher t3=new Teacher(3,"9th");
		map.put("pqr",t1);
		map.put("xyz",t2);
		map.put("abc",t3); for(Map.Entry<String,Teacher> me:map.entrySet())
		{
			System.out.println(me.getKey()+ " "+me.getValue().id+" "+me.getValue().clas);
		}
	}
}

class Teacher{
	int id;
	String clas;
	public Teacher(int id,String clas) {
		super();
		this.clas =clas;
		this.id = id;
	}
}