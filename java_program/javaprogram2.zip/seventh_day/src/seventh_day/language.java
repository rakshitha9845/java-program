package seventh_day;

import java.util.HashMap;
import java.util.Map;

public class language {

	public static void main(String[] args) {
				HashMap<String,Integer> map=new HashMap<>();
				map.put("java",79);
				map.put("php",60);
				map.put("android",90);
				
				for(Map.Entry<String,Integer> me:map.entrySet())
				{
					System.out.println(me.getKey()+ " : "+me.getValue());
				}

			}

		}