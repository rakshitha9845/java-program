package seventh_day;

import java.util.ArrayList;
import java.util.Scanner;

public class arraylist {

	public static void main(String[] args) {
		ArrayList<ArrayList> myList = new ArrayList<>();
		int arrayListCount, itemCount;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter total number of ArrayList to add : ");
		arrayListCount = scanner.nextInt();
		System.out.println("Enter total values for each ArrayList : ");
		itemCount = scanner.nextInt();
		for (int i = 0; i < arrayListCount; i++) {
		System.out.println("Enter all values for ArrayList " + (i + 1) + " : ");
		ArrayList list = new ArrayList<>();
		for (int j = 0; j < itemCount; j++) {
		System.out.println("Enter value " + (j + 1) + " : ");
		list.add(scanner.next());
		}
		myList.add(list);
		}
		System.out.println(myList);
		}
		}