package seventh_day;

import java.util.HashMap;

public class containskeymethod {

	public static void main(String[] args) {
		 HashMap<Integer, String> hash_map = new HashMap<Integer, String>();
	        hash_map.put(10, "rakshitha");
	        hash_map.put(15, "4");
	        hash_map.put(20, "mendon");
	        hash_map.put(25, "Welcomes");
	        hash_map.put(30, "You");
	  
	        System.out.println("Initial Mappings are: " + hash_map);
	        System.out.println("Is the key '20' present? " +  hash_map.containsKey(20));
	        System.out.println("Is the key '5' present? " + hash_map.containsKey(5));
	    }
	}