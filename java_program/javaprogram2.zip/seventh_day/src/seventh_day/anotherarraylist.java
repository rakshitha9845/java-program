package seventh_day;

import java.util.ArrayList;
import java.util.List;

public class anotherarraylist {

	public static void main(String[] args) {
        List<String> existingList = new ArrayList<String>();
        existingList.add("America");
        existingList.add("New York");
        existingList.add("Sidny");

        System.out.println("Existing ArrayList Object : " + existingList);
        List<String> newList = new ArrayList<String>(existingList);
        System.out.println("Newly created ArrayList Object : " + newList);
    }
}
