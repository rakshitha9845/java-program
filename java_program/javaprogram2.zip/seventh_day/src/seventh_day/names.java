package seventh_day;

import java.util.HashMap;
import java.util.Map;

public class names {

	public static void main(String[] args) {
						HashMap<Integer,String> map=new HashMap<>();
						map.put(1,"rakshitha");
						map.put(2,"xyz");
						map.put(3,"abc");
						map.put(4,"ayz");
						
						for(Map.Entry<Integer,String> me:map.entrySet())
						{
							System.out.println(me.getKey() +" : "+me.getValue());
						}

					}

				}