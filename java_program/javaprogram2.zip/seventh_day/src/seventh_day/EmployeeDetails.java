package seventh_day;

import java.util.HashMap;
import java.util.Map;

public class EmployeeDetails {

	public static void main(String[] args) {
		HashMap<String,Employee> map=new HashMap<>();
		Employee e1=new Employee("10000",1);
		Employee e2=new Employee("10000",2);
		Employee e3=new Employee("10000",3);
		map.put("rakshitha",e1);
		map.put("xyz",e2);
		map.put("abc",e3); for(Map.Entry<String,Employee> me:map.entrySet())
		{
			System.out.println(me.getKey()+ " "+me.getValue().salary+" "+me.getValue().id);
		}
	}
}

class Employee{
	String salary;
	int id;
	public Employee(String salary, int id) {
		super();
		this.salary =salary;
		this.id = id;
	}
}