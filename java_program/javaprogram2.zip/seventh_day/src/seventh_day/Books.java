package seventh_day;

import java.util.HashMap;
import java.util.Map;

public class Books {
	public static void main(String[] args) {
		HashMap<String,Book> map=new HashMap<>();
		Book b1=new Book("1",230);
		Book b2=new Book("2",560);
		Book b3=new Book("3",670);
		map.put("Java",b1);
		map.put("html",b2);
		map.put("web",b3); for(Map.Entry<String,Book> me:map.entrySet())
		{
			System.out.println(me.getKey()+ " "+me.getValue().id+" "+me.getValue().price);
		}
	}
}

class Book{
	String id;
	int price;
	public Book(String id, int price) {
		super();
		this.id = id;
		this.price = price;
	}
}

