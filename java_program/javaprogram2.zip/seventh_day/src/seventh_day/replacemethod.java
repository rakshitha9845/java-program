package seventh_day;

import java.util.HashMap;

public class replacemethod {

	public static void main(String[] args) {
		HashMap<Integer, String> languages = new HashMap<>();
	    languages.put(1, "Python");
	    languages.put(2, "English");
	    languages.put(3, "JavaScript");
	    System.out.println("HashMap: " + languages);

	    String value = languages.replace(2, "Java");

	    System.out.println("Replaced Value: " + value);
	    System.out.println("Updated HashMap: " + languages);
	  }
	}