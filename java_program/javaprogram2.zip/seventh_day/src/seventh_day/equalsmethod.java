package seventh_day;

import java.util.HashMap;

public class equalsmethod {

	public static void main(String[] args) {
		 HashMap < String, String > hm = new HashMap < String, String > ();
		  hm.put("C", "abc");
		  hm.put("C++", "pqr");
		  hm.put("Java", "xyz");
		  hm.put("Python", "mno");

		  HashMap < String, String > hm1 = new HashMap < String, String > ();

		  hm1.put("C", "abc");
		  hm1.put("C++", "pqr");
		  hm1.put("Java", "xyz");
		  hm1.put("Python", "mno");
		  boolean a = hm.equals(hm1);
		  System.out.println(a);

		  HashMap < String, Integer > hm2 = new HashMap < String, Integer > ();
		  hm2.put("aaa", 1000);
		  hm2.put("bbb", 1001);
		  hm2.put("ccc", 1002);

		  boolean b = hm.equals(hm2);
		  System.out.println(b);
		 }
		}