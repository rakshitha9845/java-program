package seventh_day;

import java.util.HashMap;
import java.util.Map;

public class demoo {

	public static void main(String[] args) {
		HashMap<String,String> map=new HashMap<>();
		map.put("key1","xyz");
		map.put("key2","xyz");
		map.put("key3","xyz");
		
		for(Map.Entry<String,String> me:map.entrySet())
		{
			System.out.println(me.getKey()+ " and "+me.getValue());
		}

	}

}
