package seventh_day;

import java.util.HashMap;
import java.util.Map;

public class color {

	public static void main(String[] args) {
		HashMap<String,String> map=new HashMap<>();
		map.put("color1","red");
		map.put("color2","black");
		map.put("color3","pink");
		
		for(Map.Entry<String,String> me:map.entrySet())
		{
			System.out.println(me.getKey()+ " : "+me.getValue());
		}

	}

}