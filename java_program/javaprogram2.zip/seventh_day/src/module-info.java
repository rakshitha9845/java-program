module seventh_day {
}