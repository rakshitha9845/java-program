module sixth_day {
}