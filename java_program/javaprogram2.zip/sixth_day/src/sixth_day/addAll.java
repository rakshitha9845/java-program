package sixth_day;

import java.util.ArrayList;

public class addAll {

	public static void main(String[] args) {
		ArrayList<String> letters = new ArrayList<>();  
		letters.add("A");  
		letters.add("B");  
		letters.add("C");  
		System.out.println(letters); 
		ArrayList<String> words = new ArrayList<>();  
		words.add("Apple");  
		words.add("Ball");  
		words.add("Cat");  
		System.out.println(words);   
		System.out.println (letters.addAll(words));   
		System.out.println(letters);   
		}
}