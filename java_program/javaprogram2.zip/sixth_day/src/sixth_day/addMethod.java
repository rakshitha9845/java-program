package sixth_day;

public class addMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
