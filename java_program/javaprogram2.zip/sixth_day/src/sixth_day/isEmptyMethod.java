package sixth_day;

import java.util.ArrayList;

public class isEmptyMethod {

	public static void main(String[] args) {
		ArrayList<Integer> arrlist = new ArrayList<Integer>(5);
		arrlist.add(25);
		arrlist.add(10);
		arrlist.add(20);
		arrlist.add(35);

		boolean retval = arrlist.isEmpty();
		if (retval == true) {
		System.out.println("list is empty");
		} else {
		System.out.println("list is not empty");
		}
		for (Integer number : arrlist) {
		System.out.println("Number = " + number);
		}
		}
		}