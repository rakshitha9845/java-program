package sixth_day;

import java.util.ArrayList;

public class demoo {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<>();//Object
        list.add("java");
        list.add("php");
        list.add("python");

        for(String x  : list)
        {
        System.out.println(x);    
        }

    }
}