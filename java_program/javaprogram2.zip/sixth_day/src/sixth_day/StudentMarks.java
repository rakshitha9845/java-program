package sixth_day;

import java.util.ArrayList;

public class StudentMarks {

	public static void main(String[] args) {
		ArrayList<Mark> list=new ArrayList<>();//Object
		Mark m1=new Mark("Manjula","300/500","350/500","400/500");
		Mark m2=new Mark("xyz","300/500","350/500","400/500");
		list.add(m1);
		list.add(m2);
		for( Mark m:list)
		{
			System.out.println(m.student+" "+m.mark1+" "+m.mark2+" "+m.mark3);
		}
	}
}
class Mark{
	String student;
	String mark1,mark2,mark3;
	public Mark(String student, String mark1,String mark2,String mark3) {
		super();
		this.student = student;
		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
	}
}